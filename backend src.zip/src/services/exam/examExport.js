exports.csv=(rows)=>{const esc=v=>`"${String(v??'').replace(/"/g,'""')}"`;return [Object.keys(rows[0]||{}).join(','),...rows.map(r=>Object.values(r).map(esc).join(','))].join('\n');};
