exports.createExpiry=(startedAt,durationMinutes)=>new Date(new Date(startedAt).getTime()+durationMinutes*60000);
exports.remainingSeconds=(expiresAt)=>Math.max(0,Math.floor((new Date(expiresAt)-Date.now())/1000));
exports.assertActive=(attempt)=>{if(!attempt.startedAt||attempt.status!=='In Progress')throw Object.assign(new Error('Attempt is not active'),{status:409});if(Date.now()>=new Date(attempt.expiresAt).getTime())throw Object.assign(new Error('Exam time has expired'),{status:409});};
