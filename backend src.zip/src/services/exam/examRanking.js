const Result=require('../../models/exam/ExamResult');
module.exports=async function recalculate(examId){
 const rows=await Result.find({exam:examId}).sort({obtainedMarks:-1,createdAt:1});
 let rank=0,last=null;
 for(let i=0;i<rows.length;i++){if(last===null||rows[i].obtainedMarks!==last)rank=i+1;rows[i].rank=rank;last=rows[i].obtainedMarks;await rows[i].save();}
 return rows;
};
