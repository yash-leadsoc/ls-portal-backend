exports.evaluateObjective=(question,answer)=>{
 const expected=[...(question.correctAnswers||[])].map(String).sort();
 const actual=(Array.isArray(answer)?answer:[answer]).filter(v=>v!=null&&v!=='').map(String).sort();
 const correct=expected.length===actual.length&&expected.every((v,i)=>v===actual[i]);
 return {correct,marks:correct?question.marks:-(question.negativeMarks||0)};
};
