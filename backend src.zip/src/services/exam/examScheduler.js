const Exam=require('../../models/exam/Exam');
module.exports=async function syncExamStatuses(){
 const now=new Date();
 await Exam.updateMany({status:{$in:['Scheduled','Live']},startsAt:{$gt:now}},{$set:{status:'Scheduled'}});
 await Exam.updateMany({status:{$in:['Scheduled','Live']},startsAt:{$lte:now},endsAt:{$gt:now}},{$set:{status:'Live'}});
 await Exam.updateMany({status:{$in:['Scheduled','Live']},endsAt:{$lte:now}},{$set:{status:'Completed'}});
};
