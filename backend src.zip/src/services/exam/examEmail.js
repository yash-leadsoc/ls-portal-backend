const nodemailer=require('nodemailer');
const EmailLog=require('../../models/exam/ExamEmailLog');
exports.sendSubmissionEmail=async(attempt,candidate)=>{
 const log=await EmailLog.create({attempt:attempt._id,to:candidate.email,subject:'Thank You for Completing the LeadSoc Examination',status:'Pending'});
 try{
  const transporter=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
  await transporter.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to:candidate.email,subject:log.subject,text:`Dear ${candidate.name},\n\nThank you for participating in the LeadSoc examination.\n\nYour examination has been successfully submitted.\n\nYour Candidate ID: ${candidate.candidateId}\n\nOur team will evaluate your performance and get back to you with further updates.\n\nRegards,\nLeadSoc Technologies`});
  log.status='Sent';log.sentAt=new Date();await log.save();
 }catch(e){log.status='Failed';log.error=e.message;await log.save();}
 return log;
};
