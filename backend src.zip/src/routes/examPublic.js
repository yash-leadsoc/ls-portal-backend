const router=require('express').Router();const c=require('../controllers/exam/examController');const candidate=require('../controllers/exam/candidateController');
router.get('/exams',c.listPublic);router.get('/exams/:id',c.getPublic);router.post('/register',candidate.register);
module.exports=router;
