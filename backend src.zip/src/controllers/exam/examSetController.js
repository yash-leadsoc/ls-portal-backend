const Set=require('../../models/exam/ExamSet');const Exam=require('../../models/exam/Exam');
exports.list=async(req,res)=>res.json(await Set.find({exam:req.params.examId}).populate('questions'));
exports.create=async(req,res)=>{if(!await Exam.exists({_id:req.params.examId}))return res.status(404).json({message:'Exam not found'});res.status(201).json(await Set.create({...req.body,exam:req.params.examId}));};
exports.update=async(req,res)=>{const x=await Set.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!x)return res.status(404).json({message:'Set not found'});res.json(x);};
exports.remove=async(req,res)=>{await Set.findByIdAndDelete(req.params.id);res.json({message:'Set deleted'});};
