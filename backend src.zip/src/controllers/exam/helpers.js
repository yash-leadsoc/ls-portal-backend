const crypto=require('crypto');
const Candidate=require('../../models/exam/ExamCandidate');
const Attempt=require('../../models/exam/ExamAttempt');
const Set=require('../../models/exam/ExamSet');
exports.newCandidateId=async()=>{const year=new Date().getFullYear();for(let i=0;i<5;i++){const id=`LS-EXAM-${year}-${crypto.randomInt(1,999999).toString().padStart(6,'0')}`;if(!await Candidate.exists({candidateId:id}))return id;}throw new Error('Could not allocate candidate ID');};
exports.newAttemptId=()=>`LSA-${crypto.randomBytes(12).toString('hex').toUpperCase()}`;
exports.newAttemptToken=()=>crypto.randomBytes(32).toString('hex');
exports.assignSet=async examId=>{const sets=await Set.find({exam:examId,isActive:true});if(!sets.length)throw Object.assign(new Error('No active question sets configured'),{status:400});return sets[crypto.randomInt(sets.length)];};
exports.publicQuestion=q=>({id:q._id,title:q.title,description:q.description,images:q.images,type:q.type,options:q.options,marks:q.marks,order:q.order});
