const Candidate=require('../../models/exam/ExamCandidate');const Exam=require('../../models/exam/Exam');const Attempt=require('../../models/exam/ExamAttempt');const crypto=require('crypto');
const {newCandidateId,newAttemptId,newAttemptToken,assignSet}=require('./helpers');
exports.register=async(req,res)=>{
 const {name,email,phone,examId}=req.body;
 if(!name||!/^\S+@\S+\.\S+$/.test(email||'')||!/^[+\d][\d\s()-]{7,19}$/.test(phone||''))return res.status(400).json({message:'Enter a valid name, email and phone number'});
 const exam=await Exam.findOne({_id:examId,status:'Live',startsAt:{$lte:new Date()},endsAt:{$gte:new Date()}});
 if(!exam)return res.status(400).json({message:'Exam is not currently available'});
 let candidate=await Candidate.findOne({exam:examId,email:email.toLowerCase()});
 if(candidate&&!exam.allowMultipleAttempts)return res.status(409).json({message:'You have already registered for this examination'});
 if(!candidate)candidate=await Candidate.create({candidateId:await newCandidateId(),name,email,phone,exam:examId});
 const prior=candidate?await Attempt.findOne({candidate:candidate._id,exam:examId}):null;
 if(prior&&!exam.allowMultipleAttempts)return res.status(409).json({message:'An attempt already exists'});
 const set=await assignSet(examId);const attemptToken=newAttemptToken();
 const attempt=await Attempt.create({attemptId:newAttemptId(),candidate:candidate._id,exam:examId,examSet:set._id,attemptTokenHash:crypto.createHash('sha256').update(attemptToken).digest('hex')});
 res.status(201).json({candidateId:candidate.candidateId,attemptId:attempt.attemptId,attemptToken,exam:{name:exam.name,durationMinutes:exam.durationMinutes,maximumMarks:exam.maximumMarks}});
};
exports.list=async(req,res)=>res.json(await Candidate.find(req.query.exam?{exam:req.query.exam}:{}).populate('exam','name').sort({createdAt:-1}));
