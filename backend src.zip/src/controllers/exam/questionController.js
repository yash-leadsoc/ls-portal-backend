const Q=require('../../models/exam/ExamQuestion');const Set=require('../../models/exam/ExamSet');
exports.list=async(req,res)=>res.json(await Q.find({set:req.params.setId}).sort({order:1}));
exports.create=async(req,res)=>{if(!await Set.exists({_id:req.params.setId}))return res.status(404).json({message:'Set not found'});const q=await Q.create({...req.body,set:req.params.setId});await Set.findByIdAndUpdate(req.params.setId,{$addToSet:{questions:q._id},$inc:{totalMarks:q.marks}});res.status(201).json(q);};
exports.update=async(req,res)=>{const q=await Q.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!q)return res.status(404).json({message:'Question not found'});res.json(q);};
exports.remove=async(req,res)=>{const q=await Q.findByIdAndDelete(req.params.id);if(q)await Set.findByIdAndUpdate(q.set,{$pull:{questions:q._id},$inc:{totalMarks:-q.marks}});res.json({message:'Question deleted'});};
