const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ROLES = ['admin', 'cto', 'bu', 'manager', 'employee'];

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    employeeCode: { type: String, trim: true },
    passwordHash: { type: String, required: true },
    passwordView: { type: String, default: null, select: false },
    role: { type: String, enum: ROLES, required: true },

    assignedDomains: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Domain',
      },
    ],
    domainAssignedAt: [
      {
        _id: false,
        domain: { type: mongoose.Schema.Types.ObjectId, ref: 'Domain' },
        at: { type: Date, default: Date.now },
      },
    ],
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },

    manager: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', default: null },
    businessUnit: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },

    active: { type: Boolean, default: true },
    enrolledAt: { type: Date, default: Date.now },

    preferredLocation: { type: String, default: '' },
    skills: { type: [String], default: [] },
    contactNumber: { type: String, default: '' },
    benchStart: { type: Date, default: null },
    deployedAt: { type: Date, default: null },
    subAdmin: { type: Boolean, default: false },
    trainerDomains: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Domain' }],
    unitAccess: [
      {
        _id: false,
        unit: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        type: { type: String, enum: ['permanent', 'temporary'], default: 'permanent' },
        since: { type: Date, default: Date.now },
      },
    ],
    loginDisabled: { type: Boolean, default: false },
    headOnly: { type: Boolean, default: false },
    trainerAccess: { type: Boolean, default: false },
    designation: { type: String, default: '' },
    permissions: { type: [String], default: undefined },
    jobStatus: { type: String, enum: ['on_training', 'ongoing_interview', 'deployed'], default: 'on_training' },

    menuConfig: { type: [String], default: [] },

    lastLoginAt: { type: Date, default: null },
    lastActiveAt: { type: Date, default: null },

    streak: {
      current: { type: Number, default: 0 },
      longest: { type: Number, default: 0 },
      lastActiveDate: { type: String, default: null },
      activeDays: { type: [String], default: [] },
    },
  },
  { timestamps: true }
);

userSchema.methods.setPassword = async function (plain) {
  this.passwordHash = await bcrypt.hash(plain, 10);
  this.passwordView = require('../utils/secretBox').encrypt(plain);
};

userSchema.methods.verifyPassword = function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

userSchema.methods.toSafeJSON = function () {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    employeeCode: this.employeeCode,
    role: this.role,
    createdBy: this.createdBy,
    manager: this.manager,
    category: this.category,
    businessUnit: this.businessUnit,
    active: this.active,
    assignedDomains: this.assignedDomains || [],
    enrolledAt: this.enrolledAt,
    preferredLocation: this.preferredLocation || '',
    skills: this.skills || [],
    contactNumber: this.contactNumber || '',
    benchStart: this.benchStart,
    deployedAt: this.deployedAt,
    subAdmin: !!this.subAdmin,
    trainerDomains: this.trainerDomains || [],
    unitAccess: (this.unitAccess || []).map((a) => ({ unit: a.unit, type: a.type, since: a.since })),
    loginDisabled: !!this.loginDisabled,
    headOnly: !!this.headOnly,
    trainerAccess: !!this.trainerAccess,
    designation: this.role === 'cto' ? this.designation || 'CTO' : this.designation || '',
    customPermissions: Array.isArray(this.permissions) && this.permissions.length ? this.permissions : null,
    jobStatus: this.jobStatus || 'on_training',
    menuConfig: this.menuConfig || [],
    streak: this.streak || { current: 0, longest: 0, lastActiveDate: null, activeDays: [] },
    lastLoginAt: this.lastLoginAt,
    lastActiveAt: this.lastActiveAt,
    createdAt: this.createdAt,
  };
};

userSchema.statics.ROLES = ROLES;

userSchema.index({ role: 1, businessUnit: 1 });
userSchema.index({ businessUnit: 1 });
userSchema.index({ manager: 1 });
userSchema.index({ employeeCode: 1 });
module.exports = mongoose.model('User', userSchema);
