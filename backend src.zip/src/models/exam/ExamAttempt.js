const mongoose=require('mongoose');
const schema=new mongoose.Schema({
 attemptId:{type:String,unique:true,index:true},
 candidate:{type:mongoose.Schema.Types.ObjectId,ref:'ExamCandidate',required:true,index:true},
 exam:{type:mongoose.Schema.Types.ObjectId,ref:'Exam',required:true,index:true},
 examSet:{type:mongoose.Schema.Types.ObjectId,ref:'ExamSet',required:true},
 status:{type:String,enum:['Registered','In Progress','Submitted','Auto Submitted','Under Evaluation','Evaluated'],default:'Registered',index:true},
 startedAt:Date,expiresAt:Date,submittedAt:Date,autoSubmitted:{type:Boolean,default:false},
 responses:[{question:{type:mongoose.Schema.Types.ObjectId,ref:'ExamQuestion'},answer:mongoose.Schema.Types.Mixed,markedForReview:{type:Boolean,default:false},savedAt:Date}],
 attemptTokenHash:String,refreshCount:{type:Number,default:0},lastHeartbeat:Date,suspiciousActivities:[mongoose.Schema.Types.Mixed],
 ipAddress:String,userAgent:String,objectiveScore:{type:Number,default:0},obtainedMarks:{type:Number,default:0},
 evaluationPending:{type:Boolean,default:true}
},{timestamps:true});
schema.index({candidate:1,exam:1});
module.exports=mongoose.models.ExamAttempt||mongoose.model('ExamAttempt',schema);
