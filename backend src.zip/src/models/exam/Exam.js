const mongoose = require('mongoose');
const ExamSchema = new mongoose.Schema({
  name:{type:String,required:true,trim:true}, description:String, instructions:String,
  category:String, durationMinutes:{type:Number,required:true,min:1},
  maximumMarks:{type:Number,required:true,min:0}, passingMarks:{type:Number,default:0},
  startsAt:Date, endsAt:Date, randomizeQuestions:{type:Boolean,default:false},
  randomizeOptions:{type:Boolean,default:false}, allowMultipleAttempts:{type:Boolean,default:false},
  negativeMarking:{type:Boolean,default:false}, negativeMarkValue:{type:Number,default:0},
  status:{type:String,enum:['Draft','Scheduled','Live','Paused','Completed','Archived'],default:'Draft'},
  createdBy:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true}
},{timestamps:true});
ExamSchema.index({status:1,startsAt:1,endsAt:1});
module.exports=mongoose.models.Exam||mongoose.model('Exam',ExamSchema);
