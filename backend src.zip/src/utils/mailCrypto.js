const crypto = require('crypto');

function key() {
  const raw = process.env.MAIL_SECRET_KEY || process.env.JWT_SECRET || '';
  if (!raw) throw new Error('Server secret is missing (JWT_SECRET)');
  return crypto.createHash('sha256').update(`tedp-mail:${raw}`).digest();
}

function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return `${iv.toString('base64')}.${c.getAuthTag().toString('base64')}.${enc.toString('base64')}`;
}

function decrypt(box) {
  const [iv, tag, data] = String(box || '').split('.');
  const d = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(iv, 'base64'));
  d.setAuthTag(Buffer.from(tag, 'base64'));
  return Buffer.concat([d.update(Buffer.from(data, 'base64')), d.final()]).toString('utf8');
}

module.exports = { encrypt, decrypt };
